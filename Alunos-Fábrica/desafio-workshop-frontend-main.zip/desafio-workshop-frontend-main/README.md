<!-- Title -->
<p align="center">
  <h1 align="center" style="font-size: 60px">Desafio Workshop Frontend </h1>
</p>

## Desafio

Criar uma página seguindo os requisitos mínimos presentes no exemplo do Figma : logo, navabar, form, título, descrição, imagem e links.

## Ideia

O tema do meu site é o salão de festas da família, Requinte Recepções, como forma de homenagem e estímulo.
